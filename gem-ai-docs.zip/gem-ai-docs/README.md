# GeM AI Document Generator

Ye ek backend app hai jo GeM bid number se company profile banaata hai via OpenAI aur DOCX file generate karta hai.
